﻿using System.Runtime.CompilerServices;
using System;

[assembly: InternalsVisibleTo("MeshBakerTests")]

public class AssemblyInfo
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
