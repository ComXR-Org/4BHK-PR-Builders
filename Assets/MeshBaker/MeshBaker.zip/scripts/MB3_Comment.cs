﻿using UnityEngine;
using System.Collections;

namespace DigitalOpus.MB.Core
{
    public class MB3_Comment : MonoBehaviour
    {
        [Multiline]
        public string comment;
    }
}
